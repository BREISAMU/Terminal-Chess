

public class tst {

    static final String ANSI_RED = "u001b[31m";
    static final String ANSI_GREY_BG = "u001b[0m";

    public static void main(String[] args){
        System.out.println(ANSI_RED + "Change my color!" + ANSI_GREY_BG);


    }
}
