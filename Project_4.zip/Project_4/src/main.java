//Import Section
import org.w3c.dom.ls.LSOutput;

import java.util.Random;
import java.util.Scanner;

/*
 * Provided in this class is the neccessary code to get started with your game's implementation
 * You will find a while loop that should take your minefield's gameOver() method as its conditional
 * Then you will prompt the user with input and manipulate the data as before in project 2
 *
 * Things to Note:
 * 1. Think back to project 1 when we asked our user to give a shape. In this project we will be asking the user to provide a mode. Then create a minefield accordingly
 * 2. You must implement a way to check if we are playing in debug mode or not.
 * 3. When working inside your while loop think about what happens each turn. We get input, user our methods, check their return values. repeat.
 * 4. Once while loop is complete figure out how to determine if the user won or lost. Print appropriate statement.
 */

public class main{
    public static void main(String[] args){
        int fChoice = 0;
        int x = 0;
        int y = 0;

        boolean isValid = false;
        String str;

        Minefield mField = new Minefield(20,20,40);

        Scanner s = new Scanner(System.in);

        while(!isValid){
            System.out.println("Enter starting coordinates:  [x] [y]");
            str = s.nextLine();

            try {
                x = Integer.parseInt(str.split(" ")[0]);
                y = Integer.parseInt(str.split(" ")[1]);
                isValid = true;
            } catch (NumberFormatException | ArrayIndexOutOfBoundsException e){
                System.out.println("Invalid guess.");
            }
        }

        mField.createMines(x, y, 40);
        mField.evaluateField();
        mField.debug();
        mField.revealStartingArea(x,y);
        mField.guess(x,y, false);


        while(!mField.gameOver()){
            isValid = false;

            System.out.println(mField);

            while(!isValid){
                System.out.println("Enter a coordinate and if you wish to place a flag (Remaining: " + mField.numFlags + "): [x] [y] [f (-1, else)]");
                str = s.nextLine();

                try {
                    x = Integer.parseInt(str.split(" ")[0]);
                    y = Integer.parseInt(str.split(" ")[1]);
                    fChoice = Integer.parseInt(str.split(" ")[2]);

                    isValid = true;
                } catch (NumberFormatException | ArrayIndexOutOfBoundsException e){
                    System.out.println("Invalid guess.");
                }
            }

            if(fChoice == -1){
                mField.guess(x, y, false);
            } else {
                mField.guess(x,y, true);
            }
        }
    }

}
